<script>
  import { username, user } from './user';

  function signout() {
    user.leave();
    username.set('');
  }



</script>

<header>
<h1>Decentralized Chat</h1>

  {#if $username}
    <div class="user-bio">
      <span>You are <strong>{$username}</strong></span>

    </div>

    <button class="signout-button" on:click={signout}>Sign Out</button>

    {:else}

      <h5>Due to being decentralized, <br>accounts are temporary, and insecure.<br> Do not enter any personal information.</h5>
  {/if}
</header>
