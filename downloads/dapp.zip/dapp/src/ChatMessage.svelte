<script>
  export let message;
  export let sender;

  const messageClass = message.who === sender ? 'sent' : 'received';

  // Function to extract initials from the user's name
  function getInitials(name) {
    const words = name.split(' ');
    return words.map(word => word[0]).join('').toUpperCase();
  }

  const userInitials = getInitials(message.who);

  const avatar = `data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40"%3E%3Ccircle cx="20" cy="20" r="18" fill="%2333cabb" /%3E%3Ctext x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-size="16" font-weight="bold" fill="%23fff"%3E${userInitials}%3C/text%3E%3C/svg%3E`;

  const ts = new Date(message.when);
</script>

<div class={`message ${messageClass}`}>
  <img src={avatar} alt="avatar" />
  <div class="message-text">
    <p>{message.what} <br><small><i>From {message.who}</i></small></p>

    <time>{ts.toLocaleTimeString(undefined, { timeZone: 'UTC' })} UTC</time>
  </div>
</div>
