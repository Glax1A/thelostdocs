<script>
  import { user } from './user';

  let username;
  let password;

  function login() {
    user.auth(username, password, ({ err }) => err && alert(err));
  }

  function signup() {
    user.create(username, password, ({ err }) => {
      if (err) {
        alert(err);
      } else {
        login();
      }
    });
  }
</script>

<label for="username">Username</label>
<input name="username" bind:value={username} minlength="1" maxlength="16" pattern="[A-Za-z0-9_!@#$:?;~&*^%£\|]+"/>

<label for="password">Password</label>
<input name="password" bind:value={password} type="password" />

<button class="login" on:click={login}>Login</button>
<button class="login"  on:click={signup}>Sign Up</button>
<br>
<center>
<p>Please note that the current encryption is insecure. I am working on upgrading the encryption to industry standard asymetric encryption.</p>
</center>
  
